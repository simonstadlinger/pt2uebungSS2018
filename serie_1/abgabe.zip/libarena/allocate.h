/*allocate.h*/

void * allocate();
void deallocate(void *data);
