#ifndef _ALLOCATE_H
#define _ALLOCATE_H

extern void *allocate();
extern void deallocate(void *data);

#endif