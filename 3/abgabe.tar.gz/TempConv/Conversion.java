package TempConv;
public abstract class Conversion{
	public abstract double convert(double val);
}
