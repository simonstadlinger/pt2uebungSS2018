package de.uni_potsdam.hpi;

public class DequeFull extends Exception {
	public DequeFull() {}

	public DequeFull(String message) {
		super(message);
	}
}
