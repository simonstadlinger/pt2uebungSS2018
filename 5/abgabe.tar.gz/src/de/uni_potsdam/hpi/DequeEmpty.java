package de.uni_potsdam.hpi;

public class DequeEmpty extends Exception {
	public DequeEmpty() {}

	public DequeEmpty(String message) {
		super(message);
	}
}
